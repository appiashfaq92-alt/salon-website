# New Supreet Unisex Salon — Website

A static website (HTML/CSS/JS, no build step needed).

## Deploy to GitHub + Vercel

1. Create a new repository on GitHub (e.g. `new-supreet-salon`).
2. Upload all files from this folder (`index.html`, the `images` folder) to that repository — keep the folder structure exactly as-is.
3. Go to [vercel.com](https://vercel.com) and log in with your GitHub account.
4. Click **"Add New" → "Project"**, then select this repository.
5. Framework preset: choose **"Other"** (it's a plain static site — no build command needed).
6. Click **Deploy**. Vercel will give you a live link (e.g. `new-supreet-salon.vercel.app`) within a minute.
7. Optional: In Vercel project settings → Domains, you can connect a custom domain later if you buy one.

That's it — the site is fully static, so every future update just needs a re-upload/push to GitHub, and Vercel auto-redeploys.

## Editing content later

- Prices/services: edit the `<div class="service-row">` blocks inside `index.html` under the "SERVICES & PRICING" section.
- Phone/WhatsApp number: search for `918057812054` in `index.html` and replace everywhere it appears.
- Photos: replace files inside the `images/` folder (keep the same filenames, or update the `src=` paths in `index.html`).
- Google review link: search for `share.google/E7TQEh1i0Rbz365h8` to update the QR code / review link.
